"use strict";
const cards = require("./data/cards.json");
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const PORT = 4000;
const app = express();

app.use(bodyParser.json());
app.use(cors());

const THEME_FACES = 'faces';
const THEME_FOOD = 'food';
const THEME_OVIPAROUS = 'oviparous';
const THEME_FLAGS = 'flags';

const faces = ['😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '🥲', '🥹', '😊', '😇', '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚', '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🥸', '🤩', '🥳', '🙂‍', '😏', '😒', '🙂‍', '😞', '😔', '😟', '😕', '🙁', '😣', '😖', '😫', '😩', '🥺', '😢', '😭', '😮‍💨', '😤', '😠', '😡', '🤬', '🤯', '😳', '🥵', '🥶', '😱', '😨', '😰', '😥', '😓', '🫣', '🤗', '🤔', '🫢', '🤭', '🤫', '🤥', '😶', '😶‍🌫️', '😐', '😑', '😬', '🫨', '🫠', '🙄', '😯', '😦', '😧', '😮', '😲', '🥱', '😴', '🤤', '😪', '😵', '😵‍💫', '🫥', '🤐', '🥴', '🤢', '🤮', '🤧', '😷', '🤒', '🤕', '🤑', '🤠', '😈', '👿', '👹', '👺', '🤡', '💩', '👻', '💀', '☠️', '👽', '👾', '🤖', '🎃', '😺', '😸', '😹', '😻', '😼', '😽', '🙀', '😿', '😾'];

const food = ['🍏', '🍎', '🍐', '🍊', '🍋', '🍌', '🍉', '🍇', '🍓', '🫐', '🍈', '🍒', '🍑', '🥭', '🍍', '🥥', '🥝', '🍅', '🍆', '🥑', '🥦', '🫛', '🥬', '🥒', '🌶', '🫑', '🌽', '🥕', '🫒', '🧄', '🧅', '🫚', '🥔', '🍠', '🫘', '🥐', '🥯', '🍞', '🥖', '🥨', '🧀', '🥚', '🍳', '🧈', '🥞', '🧇', '🥓', '🥩', '🍗', '🍖', '🦴', '🌭', '🍔', '🍟', '🍕', '🥪', '🥙', '🧆', '🌮', '🌯', '🫔', '🥗', '🥘', '🫕', '🥫', '🍝', '🍜', '🍲', '🍛', '🍣', '🍱', '🥟', '🦪', '🍤', '🍙', '🍚', '🍘', '🍥', '🥠', '🥮', '🍢', '🍡', '🍧', '🍨', '🍦', '🥧', '🧁', '🍰', '🎂', '🍮', '🍭', '🍬', '🍫', '🍿', '🍩', '🍪', '🌰', '🥜', '🍯', '🥛', '🍼', '🫖', '☕️', '🍵', '🧃', '🥤', '🧋', '🍶', '🍺', '🍻', '🥂', '🍷', '🥃', '🍸', '🍹', '🧉', '🍾', '🧊', '🥣', '🥡', '🧂'];

const oviparous = ['axolotl', 'bat', 'bee', 'butterfly', 'chameleon', 'chicken', 'clown-fish', 'crab', 'crocodile', 'dinosaur', 'dragonfly', 'ducky', 'fish', 'flamingo', 'frog', 'fish', 'flamingo', 'frog', 'jellyfish', 'lobster', 'octopus', 'parrot', 'peacock', 'penguin', 'penguinRedondo', 'scorpion', 'seagull', 'seahorse', 'shrimp', 'snake', 'stingray', 'turtle'];

const flags = [];
// GET
app.get("/", (req, res) => {
	console.log(users);
	res.send(users);
});

// POST
app.post("/", (req, res) => {
	const user = req.body;
	const userID = Date.now();
	const userWithID = { ...user, id: userID };
	users.push(userWithID);
	res.send("Added Successfully");
});

app.get("/cards/:difficulty/:theme", (req, res) => {

	if (req.params !== null &&
		req.params.difficulty !== null &&
		req.params.theme !== null) {

		let difficulty = req.params.difficulty;
		let theme = req.params.theme;
		let data = { cards: [] };
		let themeData = null;
		let isImage = false;

		switch (theme) {
			case THEME_FACES:
				themeData = faces;
				break;
			case THEME_FOOD:
				themeData = food;
				break;
			case THEME_OVIPAROUS:
				isImage = true;
				themeData = oviparous;
				break;
			case THEME_FLAGS:
				themeData = food;
				break;
			default:
				break;
		}

		for (let i = 0; i < difficulty; i++) {
			let emojiId = getRandomBetween(0, (themeData.length - 1));
			data.cards.push({
				emojiId: emojiId,
				emoji: themeData[emojiId],
				isDisconvered: false,
				isSelected: false,
				isImage: isImage
			});
		}

		let cardsCopy = data.cards.slice(0, data.cards.length);
		data.cards = data.cards.concat(cardsCopy);

		shuffleArray(data.cards);

		res.send(JSON.stringify(data));
	} else {
		res.send(JSON.stringify({ error: 'Error from server!' }));
	}
});

app.listen(PORT, () => {
	console.log(`Server running on port http://localhost:${PORT}/`);
});

// Methods 
function getRandomBetween(min, max) {
	const minCeiled = Math.ceil(min);
	const maxFloored = Math.floor(max);
	return Math.floor(Math.random() * (maxFloored - minCeiled + 1) + minCeiled); // The maximum is inclusive and the minimum is inclusive
}

function shuffleArray(array) {
	for (var i = array.length - 1; i > 0; i--) {
		var j = Math.floor(Math.random() * (i + 1));
		var temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}
}